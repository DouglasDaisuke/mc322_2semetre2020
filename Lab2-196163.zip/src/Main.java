/*	Questões:

	1) É possível escrever uma classe sem escrever nenhum construtor? Por quê?
	- Sim, pois os atributos da classe possuem um valor padrão associado, então o compilador chama um construtor padrão que configura as instâncias com esses valores.

	2) Um método estático pode acessar uma variável (atributo) não estático da classe? Por quê?
	- Não, pois os métodos estáticos estão associados a Classe e os atributos associados aos objetos da Classe, então esses atributos não estaticos são criadas apenas quando criado o objeto. Além disso não seria possivel identificar sobre qual objeto o método estático está se referindo ao acessar a variavel.

	3) Um método não estático pode acessar uma variável (atributo) estático da classe? Por quê?
	- Sim, pois os atributos estáticos são associados a Classe, então independem dos objetos sendo acessiveis pelos métodos não estáticos
 */

import java.util.Calendar;
import java.util.Scanner;  

public class Main {

	private static boolean convertIntToBoolean(int inteiro) {
		if (inteiro == 0)
			return false;
		else
			return true;
	}

	public static void main(String[] args) {
		Scanner inputStr = new Scanner(System.in);
		Scanner inputInt = new Scanner(System.in);


		/*Recebendo informações do Perfil*/
		System.out.println("Olá! Para criar uma sala, antes precisamos criar um perfil!");
		System.out.println("Insira um Login:");
		String userLogin = inputStr.nextLine();  
		System.out.println("Insira uma senha:");
		String userPassword = inputStr.nextLine();  
		System.out.println("Insira um Email existente:");
		String userEmail = inputStr.nextLine();  

		/*Recebendo informações do Cartão*/
		System.out.println("Pronto! Agora vamos fazer um cartão");
		System.out.println("Insira o nome que irá aparecer no cartão:");
		String cardName = inputStr.nextLine();  
		System.out.println("Seus convidados poderão convidar outras pessoas? 0 = não / 1 = sim ");
		int cardInvitationStatus = inputInt.nextInt();  

		/*Recebendo informações do Sala*/
		System.out.println("Por fim, insira as informações sobre sua sala");
		System.out.println("Insira a capacidade máxima:");
		int classMaximumCapacity = inputInt.nextInt();  
		System.out.println("Insira descrição da sala:");
		String classDescription = inputStr.nextLine();
		System.out.println("A entrada na sala será automática? 0 = não / 1 = sim");
		int classAutoEntryStatus = inputInt.nextInt();  
		System.out.println("***********");
		System.out.println("Pronto, sua sala foi criada!");
		System.out.println("***********");

		inputStr.close();
		inputInt.close();

		Usuario userInput = new Usuario (
				userLogin, 
				userEmail, 
				userPassword, 
				true ,
				Calendar.getInstance()
				);
		Usuario userSad = new Usuario (
				"Tristeza", 
				"tristeza@gmail.com.br", 
				"triste0123", 
				false ,
				Calendar.getInstance()
				);
		Perfil profilePersonal = new Perfil(
				'm', 
				Calendar.getInstance(), 
				"Campinas", 
				"São Paulo", 
				"(11)40028922", 
				"um perfil qualquer", 
				"uma foto aleatoria"
				);
		Perfil profileProfessional = new Perfil(
				'f', 
				Calendar.getInstance(), 
				"João Pessoa", 
				"Paraiba", 
				"(83)40028922", 
				"um perfil profissional", 
				"uma foto profissional"
				);

		Cartao cartaoPersonalizado = new Cartao(
				1,
				cardName,
				userInput,
				convertIntToBoolean(cardInvitationStatus),
				Calendar.getInstance()
				);
		Cartao cartaoBasico = new Cartao();
		Sala salaPersonalizada = new Sala(
				classMaximumCapacity,
				classDescription,
				userInput,
				convertIntToBoolean(classAutoEntryStatus),
				Calendar.getInstance()
				);
		Sala salaPadrao = new Sala();	

		System.out.println(" ");
		System.out.println(" ");
		System.out.println("Cartao Personalizado: "+ cartaoPersonalizado);
		System.out.println(" ");
		System.out.println("Cartao Básico: "+ cartaoBasico);
		System.out.println(" ");
		System.out.println("Sala Personalizada: "+ salaPersonalizada);
		System.out.println(" ");
		System.out.println("Sala Padrão: "+ salaPadrao);
		
		/*
		System.out.println("adicionando usuario... ");
		salaPersonalizada.adicionaUsuario();
		System.out.println(" "+ salaPersonalizada.getnumeroUsuarios());

		System.out.println(" ");
		System.out.println("removendo usuario... ");
		salaPersonalizada.removeUsuario();
		System.out.println(" "+ salaPersonalizada.getnumeroUsuarios());
		*/

		/*
	    System.out.println(" Atividade 1:");
	    System.out.println(" ");
		System.out.println("Usuário 1:" + userInput);
		System.out.println(" ");
	    System.out.println("Usuário 2:" + userSad);
	    System.out.println(" ");
	    System.out.println("Perfil 1:" + profilePersonal);
	    System.out.println(" ");
	    System.out.println("Perfil 2:" + profileProfessional);
		 */
	}
}
